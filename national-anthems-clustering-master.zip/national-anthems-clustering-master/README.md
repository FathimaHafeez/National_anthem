# national-anthems-clustering

This repository contains the jupyter notebook that has the clustered anthems drawn in a choropleth map in Folium.

You can read my [medium article](https://medium.com/@lucasdesa/text-clustering-with-k-means-a039d84a941b) about it!
